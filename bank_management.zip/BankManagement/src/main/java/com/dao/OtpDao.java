package com.dao;

import com.model.Otp;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class OtpDao {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Transactional
    public void save(Otp otp) {
        getSession().persist(otp);
    }
    
    @Transactional
    public void delete(Otp otp) {
        getSession().remove(otp);
    }

    @Transactional(readOnly = true)
    public Otp findByEmail(String email) { 
        String hql = "FROM Otp WHERE email = :email"; 
        Query<Otp> query = getSession().createQuery(hql, Otp.class);
        query.setParameter("email", email);
        return query.uniqueResult(); 
    }
    
    @Transactional
    public void deleteByEmail(String email) { 
        String hql = "DELETE FROM Otp WHERE email = :email";
        Query<?> query = getSession().createQuery(hql);
        query.setParameter("email", email);
        query.executeUpdate();
    }
}