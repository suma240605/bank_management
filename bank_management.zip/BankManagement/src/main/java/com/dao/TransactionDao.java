package com.dao;

import com.model.Transaction;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public class TransactionDao {

    @Autowired
    private SessionFactory sessionFactory;

    private Session getSession() {
        return sessionFactory.getCurrentSession();
    }

    @Transactional
    public void save(Transaction transaction) {
        getSession().persist(transaction);
    }

    // Dynamic History Method
    @Transactional(readOnly = true)
    public List<Transaction> findRecentByAccountNumber(String accountNumber, int limit) {
        String hql = "FROM Transaction WHERE accountNumber = :accNum ORDER BY transactionDate DESC";
        
        return getSession().createQuery(hql, Transaction.class)
                           .setParameter("accNum", accountNumber)
                           .setMaxResults(limit)
                           .getResultList();
    }
}