package com.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Loan;

@Repository
public class LoanDao {

    @Autowired
    private SessionFactory sessionFactory;

    public void saveLoan(Loan loan) {
        sessionFactory.getCurrentSession().save(loan);
    }

    public List<Loan> getAllLoans() {
        return sessionFactory.getCurrentSession()
                .createQuery("from Loan", Loan.class)
                .list();
    }

    public Loan getLoanById(Long id) {
        return sessionFactory.getCurrentSession().get(Loan.class, id);
    }

    public void updateLoan(Loan loan) {
        sessionFactory.getCurrentSession().update(loan);
    }
}
