package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.model.BankAccount;
import com.model.Loan;
import com.service.BankAccountService;
import com.service.DashboardService;
import com.service.DashboardService.DashboardData;
import com.service.LoanService;
import com.service.OtpService;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {

    @Autowired
    private DashboardService dashboardService;

    @Autowired
    private OtpService otpService;

    @Autowired
    private BankAccountService bankAccountService;

    @Autowired
    private LoanService loanService;

    @GetMapping("/")
    public String showLandingPage() {
        return "index";
    }

    @GetMapping("/register")
    public ModelAndView showRegisterPage() {
        ModelAndView mav = new ModelAndView("register");
        mav.addObject("bankAccount", new BankAccount());
        return mav;
    }

    @PostMapping("/register")
    public String processRegister(@ModelAttribute BankAccount account,
                                  RedirectAttributes redirectAttributes) {
        BankAccount existing = bankAccountService.getAccountByEmail(account.getEmail());
        if (existing != null) {
            redirectAttributes.addFlashAttribute("error", "Email already registered. Please login.");
            return "redirect:/login";
        }
        String newAccNum = bankAccountService.generateUniqueAccountNumber();
        account.setAccountNumber(newAccNum);
        if (account.getInitialDeposit() != null && (account.getBalance() == null || account.getBalance() == 0.0)) {
            account.setBalance(account.getInitialDeposit());
        }
        account.setPasswordHash(account.getPassword());
        account.setPassword(null);
        account.setMustResetPassword(true);
        try {
            bankAccountService.saveBankAccount(account);
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", "Registration failed due to a server error.");
            return "redirect:/register";
        }
        redirectAttributes.addFlashAttribute("message", "Account created successfully! Your Account Number is " + newAccNum + ". Please verify your login.");
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String processLogin(@RequestParam("email") String email,
                               @RequestParam("password") String password,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        BankAccount account = bankAccountService.authenticateAccount(email, password);
        if (account != null) {
            session.setAttribute("currentUser", account);
            if (account.isMustResetPassword()) {
                session.setAttribute("mustResetPending", true);
                return "redirect:/reset-password";
            } else {
                session.setAttribute("otpPending", true);
                return "redirect:/get-email";
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid Credentials.");
            return "redirect:/login";
        }
    }

    @GetMapping("/reset-password")
    public ModelAndView showResetPasswordPage(HttpSession session, RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        Boolean mustResetPending = (Boolean) session.getAttribute("mustResetPending");
        if (account == null || !account.isMustResetPassword() || mustResetPending == null || !mustResetPending) {
            redirectAttributes.addFlashAttribute("error", "Security token required.");
            return new ModelAndView("redirect:/login");
        }
        return new ModelAndView("resetpassword");
    }

    @PostMapping("/reset-password")
    public String processResetPassword(@RequestParam("newPassword") String newPassword,
                                       HttpSession session,
                                       RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        Boolean mustResetPending = (Boolean) session.getAttribute("mustResetPending");
        if (account != null && account.isMustResetPassword() && mustResetPending != null && mustResetPending) {
            bankAccountService.resetPassword(account, newPassword);
            account.setMustResetPassword(false);
            session.removeAttribute("mustResetPending");
            session.setAttribute("otpPending", true);
            redirectAttributes.addFlashAttribute("message", "Password reset successfully. Please verify OTP.");
            return "redirect:/get-email";
        }
        redirectAttributes.addFlashAttribute("error", "Session expired or invalid state.");
        return "redirect:/login";
    }

    @GetMapping("/get-email")
    public String showGetEmailPage(HttpSession session, RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        Boolean otpPending = (Boolean) session.getAttribute("otpPending");
        if (account == null || otpPending == null || !otpPending) {
            redirectAttributes.addFlashAttribute("error", "Login session required.");
            return "redirect:/login";
        }
        return "getemail";
    }

    @PostMapping("/send-otp")
    public String processSendOtp(@RequestParam(value = "email", required = false) String email,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        if (email == null || email.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Email is required.");
            return "redirect:/get-email";
        }
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        if (account == null) {
            redirectAttributes.addFlashAttribute("error", "Please login first.");
            return "redirect:/login";
        }
        String registeredEmail = account.getEmail();
        if (!registeredEmail.equalsIgnoreCase(email)) {
            redirectAttributes.addFlashAttribute("error", "Entered email does not match registered email.");
            return "redirect:/get-email";
        }
        otpService.generateAndSendOtp(account, email);
        redirectAttributes.addFlashAttribute("message", "OTP sent to " + email);
        return "redirect:/verify-otp";
    }


    @GetMapping("/verify-otp")
    public String showVerifyOtpPage(HttpSession session, Model model, RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        Boolean otpPending = (Boolean) session.getAttribute("otpPending");
        if (account == null || otpPending == null || !otpPending) {
            redirectAttributes.addFlashAttribute("error", "Access denied.");
            return "redirect:/login";
        }
        model.addAttribute("currentUser", account); // Add currentUser to the model
        return "verifyotp";
    }


    @PostMapping("/verify-otp")
    public String processVerifyOtp(@RequestParam("otpCode") String otpCode,
                                   HttpSession session,
                                   RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        Boolean otpPending = (Boolean) session.getAttribute("otpPending");
        if (account == null || otpPending == null || !otpPending) {
            redirectAttributes.addFlashAttribute("error", "Session invalid.");
            return "redirect:/login";
        }
        if (otpService.validateOtp(account.getEmail(), otpCode)) {
            session.removeAttribute("otpPending");
            return "redirect:/dashboard";
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid OTP. Please try again.");
            return "redirect:/verify-otp";
        }
    }

    @GetMapping("/dashboard")
    public ModelAndView showDashboard(HttpSession session, RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        if (account == null) {
            redirectAttributes.addFlashAttribute("error", "Please log in.");
            return new ModelAndView("redirect:/login");
        }
        DashboardData dashboardData = dashboardService.getDashboardData(account);
        ModelAndView mav = new ModelAndView("dashboard");
        mav.addObject("dashboardData", dashboardData);
        return mav;
    }

    @GetMapping("/logout")
    public String logout(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("message", "You have been logged out successfully.");
        return "redirect:/";
    }

    @GetMapping("/transfer")
    public ModelAndView showTransferForm(HttpSession session, RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        if (account == null) {
            redirectAttributes.addFlashAttribute("error", "Please log in to transfer funds.");
            return new ModelAndView("redirect:/login");
        }
        ModelAndView mav = new ModelAndView("transfer");
        mav.addObject("account", account);
        return mav;
    }

    @PostMapping("/transfer")
    public String processTransfer(@RequestParam("targetAccountNumber") String targetAccountNumber,
                                  @RequestParam("amount") Double amount,
                                  HttpSession session,
                                  RedirectAttributes redirectAttributes) {
        BankAccount sourceAccount = (BankAccount) session.getAttribute("currentUser");
        if (sourceAccount == null) {
            redirectAttributes.addFlashAttribute("error", "Session expired. Please log in.");
            return "redirect:/login";
        }
        if (amount == null || amount <= 0) {
            redirectAttributes.addFlashAttribute("error", "Transfer amount must be positive.");
            return "redirect:/transfer";
        }
        if (targetAccountNumber == null || targetAccountNumber.isEmpty()) {
            redirectAttributes.addFlashAttribute("error", "Target account number is required.");
            return "redirect:/transfer";
        }
        try {
            bankAccountService.performTransfer(sourceAccount, targetAccountNumber, amount);
            session.setAttribute("currentUser", bankAccountService.getAccountByAccountNumber(sourceAccount.getAccountNumber()));
            redirectAttributes.addFlashAttribute("message", String.format("Successfully transferred $%.2f to account %s.", amount, targetAccountNumber));
            return "redirect:/dashboard";
        } catch (IllegalArgumentException e) {
            redirectAttributes.addFlashAttribute("error", "Transfer failed: " + e.getMessage());
            return "redirect:/transfer";
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", "A system error occurred during the transfer.");
            return "redirect:/transfer";
        }
    }

    @GetMapping("/deposit")
    public ModelAndView showDepositForm(HttpSession session, RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        if (account == null) {
            redirectAttributes.addFlashAttribute("error", "Please log in to make a deposit.");
            return new ModelAndView("redirect:/login");
        }
        ModelAndView mav = new ModelAndView("deposit");
        mav.addObject("account", account);
        return mav;
    }

    @PostMapping("/deposit")
    public String processDeposit(@RequestParam("amount") Double amount,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        if (account == null) {
            redirectAttributes.addFlashAttribute("error", "Session expired. Please log in.");
            return "redirect:/login";
        }
        if (amount == null || amount <= 0) {
            redirectAttributes.addFlashAttribute("error", "Deposit amount must be positive.");
            return "redirect:/deposit";
        }
        try {
            bankAccountService.performDeposit(account, amount);
            session.setAttribute("currentUser", bankAccountService.getAccountByAccountNumber(account.getAccountNumber()));
            redirectAttributes.addFlashAttribute("message", String.format("Successfully deposited $%.2f into your account.", amount));
            return "redirect:/dashboard";
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", "A system error occurred during the deposit.");
            return "redirect:/deposit";
        }
    }

    @GetMapping("/applyLoan")
    public String showLoanForm(Model model) {
        model.addAttribute("loan", new Loan());
        return "applyLoan";
    }

    @PostMapping("/submitLoanApplication")
    public String submitLoanApplication(@ModelAttribute("loan") Loan loan, HttpSession session, Model model) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        if (account != null) {
            loan.setStatus("PENDING");
            loan.setAccount(account); 
            loanService.saveLoan(loan);
            model.addAttribute("message", "Your loan application has been submitted successfully! Status: " + loan.getStatus());
            return "loanSuccess";
        }
        model.addAttribute("error", "You must be logged in to apply for a loan.");
        return "redirect:/login";
    }


    @GetMapping("/loanStatus")
    public String viewLoanStatus(HttpSession session, Model model) {
        BankAccount account = (BankAccount) session.getAttribute("currentUser");
        if (account != null) {
            List<Loan> loans = loanService.getLoansByUser(account);
            model.addAttribute("loans", loans);
            return "loanStatus";
        }
        model.addAttribute("error", "You must be logged in to view loan status.");
        return "redirect:/login";
    }

    @PostMapping("/approveLoan")
    public String approveLoan(@RequestParam("loanId") Long loanId, RedirectAttributes redirectAttributes) {
        try {
            loanService.approveLoan(loanId);
            redirectAttributes.addFlashAttribute("message", "Loan approved successfully!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", "Failed to approve loan: " + e.getMessage());
        }
        return "redirect:/AdminLoanDashboard";
    }

    @PostMapping("/rejectLoan")
    public String rejectLoan(@RequestParam("loanId") Long loanId, RedirectAttributes redirectAttributes) {
        try {
            loanService.rejectLoan(loanId);
            redirectAttributes.addFlashAttribute("message", "Loan rejected successfully!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", "Failed to reject loan: " + e.getMessage());
        }
        return "redirect:/AdminLoanDashboard";
    }
    

    @GetMapping("/AdminLoanDashboard")
    public String showAdminDashboard() {
        return "AdminLoanDashboard"; 
    }

    @GetMapping("/adminLogin")
    public String showAdminLoginPage() {
        return "adminLogin";
    }

    @PostMapping("/validateAdmin")
    public String validateAdmin(@RequestParam("username") String username,
                                @RequestParam("password") String password,
                                Model model) {
        if ("admin".equals(username) && "admin123".equals(password)) {
            return "redirect:/admin/loans";
        } else {
            model.addAttribute("error", "Invalid credentials");
            return "adminLogin";
        }
    }

    @GetMapping("/admin/loans")
    public String viewLoans(Model model) {
        List<Loan> loanList = loanService.getAllLoans();
        model.addAttribute("loans", loanList);

        model.addAttribute("totalLoans", loanList.size());
        model.addAttribute("pendingLoans", loanList.stream().filter(l -> "PENDING".equals(l.getStatus())).count());
        model.addAttribute("approvedLoans", loanList.stream().filter(l -> "APPROVED".equals(l.getStatus())).count());
        model.addAttribute("rejectedLoans", loanList.stream().filter(l -> "REJECTED".equals(l.getStatus())).count());

        return "AdminLoanDashboard";
    }

    @GetMapping("/admin/users")
    public String manageUsers(Model model) {
        List<BankAccount> users = bankAccountService.getAllAccounts();
        model.addAttribute("users", users);
        return "AdminManageUsers";
    }

    @GetMapping("/adminlogout")  
    public String adminLogout(HttpSession session) {
        session.invalidate();
        return "redirect:/adminLogin";
    }


}
