package com.model;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "bank_accounts")
public class BankAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "account_number", nullable = false, unique = true, length = 15)
    private String accountNumber; 

    @Column(nullable = false)
    private boolean mustResetPassword = true; 

    @Column(name = "password_hash", nullable = false, length = 255) 
    private String passwordHash; 

    @Transient 
    private String password; 

    @Column(nullable = false, length = 100)
    private String fullName;

    @Column(nullable = false, unique = true, length = 100)
    private String email; 

    @Column(nullable = false)
    private LocalDate dob;

    private String gender;

    @Column(nullable = false)
    private String accountType;

    private Double balance;

    private String branch;

    private String phone;
    private String address;
    private String city;
    private String state;
    private String country;
    private String pincode;
    
    private Double initialDeposit;
    
    public BankAccount() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }
    public String getAccountType() { return accountType; }
    public void setAccountType(String accountType) { this.accountType = accountType; }
    public Double getBalance() { return balance; }
    public void setBalance(Double balance) { this.balance = balance; }
    public Double getInitialDeposit() { return initialDeposit; }
	public void setInitialDeposit(Double initialDeposit) { this.initialDeposit = initialDeposit; }
    public boolean isMustResetPassword() { return mustResetPassword; }
    public void setMustResetPassword(boolean mustResetPassword) { this.mustResetPassword = mustResetPassword; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }
    public String getBranch() { return branch; }
    public void setBranch(String branch) { this.branch = branch; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }
    public String getPincode() { return pincode; }
    public void setPincode(String pincode) { this.pincode = pincode; }
}