package com.model;

import java.time.LocalDate;
import jakarta.persistence.*;

@Entity
@Table(name = "loans")
public class Loan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String type;              
    private Double amount;
    private Integer durationMonths;   
    private Double interestRate;      
    private String status;            
    private LocalDate appliedDate;   
    private LocalDate approvedDate;   

    @ManyToOne
    @JoinColumn(name = "account_id")
    private BankAccount account;

    private String purpose;           
    private String collateral;        

    public Loan() {
        this.appliedDate = LocalDate.now();
        this.status = "PENDING";
    }

    public Long getId() { return id; }

    public void setId(Long id) { this.id = id; }

    public String getType() { return type; }

    public void setType(String type) { this.type = type; }

    public Double getAmount() { return amount; }

    public void setAmount(Double amount) { this.amount = amount; }

    public Integer getDurationMonths() { return durationMonths; }

    public void setDurationMonths(Integer durationMonths) { this.durationMonths = durationMonths; }

    public Double getInterestRate() { return interestRate; }

    public void setInterestRate(Double interestRate) { this.interestRate = interestRate; }

    public String getStatus() { return status; }

    public void setStatus(String status) { this.status = status; }

    public LocalDate getAppliedDate() { return appliedDate; }

    public void setAppliedDate(LocalDate appliedDate) { this.appliedDate = appliedDate; }

    public LocalDate getApprovedDate() { return approvedDate; }

    public void setApprovedDate(LocalDate approvedDate) { this.approvedDate = approvedDate; }

    public BankAccount getAccount() { return account; }

    public void setAccount(BankAccount account) { this.account = account; }

    public String getPurpose() { return purpose; }

    public void setPurpose(String purpose) { this.purpose = purpose; }

    public String getCollateral() { return collateral; }

    public void setCollateral(String collateral) { this.collateral = collateral; }
}
