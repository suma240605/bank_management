package com.service;

import com.dao.TransactionDao;
import com.model.BankAccount;
import com.model.Transaction;
import jakarta.persistence.NoResultException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;

@Service
public class BankAccountService {

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    private TransactionDao transactionDao;

    @Transactional(readOnly = true)
    public String generateUniqueAccountNumber() {
        Random random = new Random();
        String newAccNum;
        do {
            long tenDigitNumber = 1000000000L + (long)(random.nextDouble() * 9000000000L);
            newAccNum = "ACC" + tenDigitNumber;
        } while (getAccountByAccountNumber(newAccNum) != null);
        return newAccNum;
    }

    @Transactional(readOnly = true)
    public BankAccount getAccountByAccountNumber(String accountNumber) {
        Session session = sessionFactory.getCurrentSession();
        try {
            Query<BankAccount> query = session.createQuery(
                "FROM BankAccount WHERE accountNumber = :accNum", BankAccount.class);
            query.setParameter("accNum", accountNumber);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public BankAccount getAccountByEmail(String email) {
        Session session = sessionFactory.getCurrentSession();
        try {
            Query<BankAccount> query = session.createQuery(
                "FROM BankAccount WHERE email = :email", BankAccount.class);
            query.setParameter("email", email);
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Transactional(readOnly = true)
    public BankAccount authenticateAccount(String email, String password) {
        Session session = sessionFactory.getCurrentSession();
        String hql = "FROM BankAccount WHERE email = :email AND passwordHash = :pass"; 
        return session.createQuery(hql, BankAccount.class)
                      .setParameter("email", email)
                      .setParameter("pass", password)
                      .uniqueResult();
    }

    @Transactional
    public void resetPassword(BankAccount account, String newPassword) {
        account.setPasswordHash(newPassword);
        account.setMustResetPassword(false);
        sessionFactory.getCurrentSession().merge(account);
    }

    @Transactional
    public void saveBankAccount(BankAccount account) {
        sessionFactory.getCurrentSession().save(account);
    }

    @Transactional
    public void updateAccount(BankAccount account) {
        sessionFactory.getCurrentSession().merge(account);
    }

    @Transactional
    public void performDeposit(BankAccount account, Double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Deposit must be positive.");
        Session session = sessionFactory.getCurrentSession();
        BankAccount persistentAccount = session.get(BankAccount.class, account.getId());
        persistentAccount.setBalance(persistentAccount.getBalance() + amount);

        Transaction depositTx = createTransaction(persistentAccount.getAccountNumber(), 
                                                  new BigDecimal(amount), 
                                                  "Deposit", "CREDIT");
        transactionDao.save(depositTx);
    }

    @Transactional
    public void performTransfer(BankAccount sourceAccount, String targetAccountNumber, Double amount) {
        if (amount <= 0) throw new IllegalArgumentException("Transfer must be positive.");
        Session session = sessionFactory.getCurrentSession();

        BankAccount persistentSource = session.get(BankAccount.class, sourceAccount.getId());
        BankAccount persistentTarget = getAccountByAccountNumber(targetAccountNumber);

        if (persistentTarget == null) throw new IllegalArgumentException("Target account not found.");
        if (persistentSource.getBalance() < amount) throw new IllegalArgumentException("Insufficient funds.");
        if (persistentSource.getAccountNumber().equals(targetAccountNumber))
            throw new IllegalArgumentException("Cannot transfer to the same account.");

        persistentSource.setBalance(persistentSource.getBalance() - amount);
        persistentTarget.setBalance(persistentTarget.getBalance() + amount);
        session.merge(persistentTarget);

        BigDecimal txAmount = new BigDecimal(amount);
        Transaction debitTx = createTransaction(persistentSource.getAccountNumber(), txAmount.negate(),
                                               "Transfer OUT to " + targetAccountNumber, "DEBIT");
        Transaction creditTx = createTransaction(persistentTarget.getAccountNumber(), txAmount,
                                                "Transfer IN from " + persistentSource.getAccountNumber(), "CREDIT");
        transactionDao.save(debitTx);
        transactionDao.save(creditTx);
    }

    private Transaction createTransaction(String accountNumber, BigDecimal amount, String desc, String type) {
        Transaction tx = new Transaction();
        tx.setAccountNumber(accountNumber);
        tx.setTransactionDate(LocalDateTime.now());
        tx.setAmount(amount);
        tx.setDescription(desc);
        tx.setType(type);
        return tx;
    }

    @Transactional(readOnly = true)
    public List<BankAccount> getAllAccounts() {
        return sessionFactory.getCurrentSession()
                             .createQuery("FROM BankAccount", BankAccount.class)
                             .getResultList();
    }
}
