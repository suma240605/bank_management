package com.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.BankAccount;
import com.model.Loan;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class LoanService {

    @PersistenceContext
    private EntityManager em;

    public void saveLoan(Loan loan) {
        em.persist(loan);
    }

    public List<Loan> getLoansByUser(BankAccount account) {
        return em.createQuery("SELECT l FROM Loan l WHERE l.account = :account", Loan.class)
                 .setParameter("account", account)
                 .getResultList();
    }

    public List<Loan> getAllLoans() {
        return em.createQuery("SELECT l FROM Loan l", Loan.class).getResultList();
    }

    public void approveLoan(Long loanId) {
        Loan loan = em.find(Loan.class, loanId);
        if (loan != null && "PENDING".equals(loan.getStatus())) {
            loan.setStatus("APPROVED");
            loan.setApprovedDate(LocalDate.now());
            em.merge(loan);
        } else {
            throw new RuntimeException("Loan not found or already processed");
        }
    }

    public void rejectLoan(Long loanId) {
        Loan loan = em.find(Loan.class, loanId);
        if (loan != null && "PENDING".equals(loan.getStatus())) {
            loan.setStatus("REJECTED");
            em.merge(loan);
        } else {
            throw new RuntimeException("Loan not found or already processed");
        }
    }
}
