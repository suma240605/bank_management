package com.service;

import com.dao.OtpDao;
import com.model.Otp;
import com.model.BankAccount; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Random;

@Service
public class OtpService {

    private static final long OTP_VALIDITY_SECONDS = 60;

    @Autowired
    private OtpDao otpDao;

    @Autowired
    private JavaMailSender mailSender; 
    
    @Transactional
    public String generateAndSendOtp(BankAccount account, String recipientEmail) {
        otpDao.deleteByEmail(account.getEmail());

        String otpCode = String.format("%06d", new Random().nextInt(1000000));

        Otp newOtp = new Otp();
        newOtp.setEmail(account.getEmail());
        newOtp.setOtpCode(otpCode);
        newOtp.setCreatedAt(LocalDateTime.now());
        otpDao.save(newOtp);

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom("sumalikhithaguddeti@gmail.com"); 
        message.setTo(recipientEmail);
        message.setSubject("Your OTP Code");
        message.setText("Dear " + account.getFullName() + ",\n\n"
                        + "Your OTP is: " + otpCode
                        + "\nThis OTP is valid for 60 seconds."
                        + "\n\nBest Regards,\nBank App Team");

        mailSender.send(message);

        System.out.println("✅ OTP email sent to " + recipientEmail);

        return otpCode;
    }

    @Transactional
    public boolean validateOtp(String email, String code) {
        Otp otp = otpDao.findByEmail(email);

        if (otp == null || !otp.getOtpCode().equals(code)) {
            return false; 
        }

        long secondsElapsed = Duration.between(otp.getCreatedAt(), LocalDateTime.now()).getSeconds();

        if (secondsElapsed > OTP_VALIDITY_SECONDS) {
            otpDao.delete(otp); 
            return false;
        }

        otpDao.delete(otp); 
        return true;
    }
}
