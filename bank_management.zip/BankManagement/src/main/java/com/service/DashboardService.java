package com.service;

import com.dao.TransactionDao;
import com.model.BankAccount;
import com.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.ArrayList;

@Service
public class DashboardService {
    
    @Autowired
    private TransactionDao transactionDao; 

    public DashboardData getDashboardData(BankAccount account) { 
        DashboardData data = new DashboardData();

        data.setAccount(account); 

        AccountSummary checkingAccount = new AccountSummary(
            account.getAccountNumber(), 
            account.getBalance() != null ? account.getBalance() : 0.0
        );
        data.setCheckingAccount(checkingAccount);

        List<Transaction> transactions = new ArrayList<>();
        
        try {
            transactions = transactionDao.findRecentByAccountNumber(account.getAccountNumber(), 10);
            
            if (transactions.isEmpty()) {
                Transaction initialTx = new Transaction();
                initialTx.setDescription("Initial Deposit");
                initialTx.setAmount(new BigDecimal(account.getInitialDeposit().toString()));
                initialTx.setType("CREDIT");
                transactions.add(initialTx);
            }
            
        } catch (Exception e) {
            System.err.println("Error fetching transactions: " + e.getMessage());
            Transaction failTx = new Transaction();
            failTx.setDescription("ERROR: Failed to load history");
            failTx.setAmount(BigDecimal.ZERO);
            failTx.setType("DEBIT");
            transactions.add(failTx);
        }
        
        data.setRecentTransactions(transactions);
        return data;
    }


    public static class DashboardData {
        private BankAccount account;
        private AccountSummary checkingAccount;
        private List<Transaction> recentTransactions;

        public BankAccount getAccount() { return account; }
        public void setAccount(BankAccount account) { this.account = account; }
        
        public AccountSummary getCheckingAccount() { return checkingAccount; }
        public void setCheckingAccount(AccountSummary checkingAccount) { this.checkingAccount = checkingAccount; }

        public List<Transaction> getRecentTransactions() { return recentTransactions; }
        public void setRecentTransactions(List<Transaction> recentTransactions) { this.recentTransactions = recentTransactions; }
    }

    public static class AccountSummary {
        private String accountNumber;
        private double currentBalance;

        public AccountSummary(String accountNumber, double currentBalance) {
            this.accountNumber = accountNumber;
            this.currentBalance = currentBalance;
        }

        public String getAccountNumber() { return accountNumber; }
        public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }

        public double getCurrentBalance() { return currentBalance; }
        public void setCurrentBalance(double currentBalance) { this.currentBalance = currentBalance; }
    }
}